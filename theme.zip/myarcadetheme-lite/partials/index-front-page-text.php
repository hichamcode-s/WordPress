<?php if ( myarcadetheme_get_option( 'front_page_text_status', '1' ) ) : ?>
  <div id="front_page_text" class="blk-cn">
    <div class="titl"><?php echo myarcadetheme_get_option( 'front_page_text_title' ); ?></div>
   <span> <?php echo myarcadetheme_get_option( 'front_page_text_content' ); ?> </span>
  </div>
<?php endif; ?>