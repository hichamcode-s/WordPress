<div class="titl-404">
  <?php _e('Oops!', 'myarcadetheme'); ?>
</div>

<p><?php _e("This game has no mobile version. Please try another one!", 'myarcadetheme'); ?></p>

<?php get_template_part( "partials/form", "search" ); ?>