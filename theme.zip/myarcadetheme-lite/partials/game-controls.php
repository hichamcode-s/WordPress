<?php if ( function_exists( "myarcadecontrols_output" ) ) : ?>
<div class="blk-cn">
  <?php echo myarcadecontrols_output(); ?>
</div>
<?php endif; ?>