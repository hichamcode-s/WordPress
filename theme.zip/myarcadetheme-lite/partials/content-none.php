<div class="titl-404">
  <?php _e('404', 'myarcadetheme'); ?>
</div>

<p>
  <?php _e("Sorry, the page you asked for couldn't be found. Please, try to use the search form below.", 'myarcadetheme'); ?>
</p>

<?php get_template_part( "partials/form", "search" ); ?>