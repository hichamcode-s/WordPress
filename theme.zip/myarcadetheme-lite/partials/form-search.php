<div class="srch404">
  <form method="get" id="search_form" action="<?php bloginfo ('url'); ?>">
    <input name="s" id="s" type="text" placeholder="<?php _e('Search game...', 'myarcadetheme'); ?>">
    <button name="btn_search" type="submit"><span class="fa-search"><?php _e('Search', 'myarcadetheme'); ?></span></button>
  </form>
</div>