jQuery(document).ready(function($) {
  $("#game_opts a.fa-share-alt").click( function(e) {
    e.preventDefault();
  });
});